
* compile file  
`$ make`  
or  
`$ gcc -c client.c`  
`$ gcc client.o -o client`  

* executable client  
`$ ./client`  
  
* required environment:  
Linux  

